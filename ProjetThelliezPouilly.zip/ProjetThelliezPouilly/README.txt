﻿Projet de C de Pouilly Christopher et Thelliez Favien.
Il s'agit d'un module d'arbre généalogique sous forme textuel dans la console.

Pour tester les fonctionnalités, une famille test est contenu dans SAVE.txt
Cette famille s'obtient dans la console en tapant load(SAVE.txt) et en ayant le fichier dans le même dossier.

L'arbre généalogique de cette famille test est donné fichier annexe (arbreTest.png)