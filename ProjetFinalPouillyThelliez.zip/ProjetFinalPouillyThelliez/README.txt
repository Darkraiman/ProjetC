﻿Projet de C de Pouilly Christopher et Thelliez Favien.
Il s'agit d'un module d'arbre généalogique sous forme textuel dans la console.

Pour tester les fonctionnalités, une famille test est contenu dans SAVE.txt
Cette famille s'obtient dans la console en tapant load(SAVE.txt) et en ayant le fichier dans le même dossier.

L'arbre généalogique de cette famille test est donné fichier annexe (arbreTest.png).

Un personne peut être ajouté de plusieurs façons :
new(prenom,sexe,nompere,nommere,datenaissance,datedeces,isoNaissance)
ou
new(prenom) (les derniers peuvent être oublié si ils sont tous dans l'ordre)
ou
new(prenom,,nompere,nommere,datenaissance,,isoNaissance) (double , pour ignorer un paramètre) 

On ne stocke pas les origines (avec le save) car elles peuvent être retrouver avec l'arbre.

Notre programme ne contient pas normalement de fuite mémoire.



